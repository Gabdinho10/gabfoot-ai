# GABFOOT AI — prototype Flutter

Cette version comprend :
- les logos des clubs transmis, intégrés dans `assets/clubs/` ;
- le calendrier complet de la phase de ligue UEFA Champions League 2026/27 fourni dans la conversation (8 journées, 144 rencontres) ;
- les rencontres classées par journée, avec date, heure, équipes et logos disponibles ;
- une interface sombre avec accents bleu électrique.

## Important
Le calendrier est celui du document fourni et les horaires y sont reproduits tels qu'indiqués. Les horaires ne sont pas convertis selon le fuseau local. Le calendrier est statique : il ne se met pas encore à jour automatiquement.

Les scores en direct et les probabilités affichées dans les écrans de démonstration ne sont pas connectés à une API et ne doivent pas être considérés comme des données réelles.

## Compilation Android
Ce dossier contient le code source Flutter, pas encore un fichier APK. Pour générer l'APK, il faut l'envoyer vers un service de compilation Flutter en ligne ou le compiler avec Flutter :

```bash
flutter pub get
flutter build apk --release
```

L'APK de sortie se trouve normalement dans `build/app/outputs/flutter-apk/app-release.apk`.
