import 'package:flutter/material.dart';

void main() => runApp(const GabfootApp());

const electricBlue = Color(0xFF168BFF);
const pageBg = Color(0xFF080D16);
const cardBg = Color(0xFF121C2B);

const clubLogos = <String, String>{
  'Real Madrid C.F.': 'assets/clubs/real-madrid-logo-footylogos.png',
  'AS Roma': 'assets/clubs/roma-logo-footylogos.png',
  'Sabah FC': 'assets/clubs/sabah-fk-logo-footylogos.png',
  'FC Shakhtar Donetsk': 'assets/clubs/shakhtar-donetsk-logo-footylogos.png',
  'SK Slavia Praha': 'assets/clubs/slavia-praha-logo-footylogos.png',
  'ŠK Slovan Bratislava': 'assets/clubs/sk-slovan-bratislava-logo-footylogos.png',
  'Sporting Clube de Portugal': 'assets/clubs/sporting-cp-logo-footylogos.png',
  'VfB Stuttgart': 'assets/clubs/vfb-stuttgart-logo-footylogos.png',
  'Viking FK': 'assets/clubs/viking-fk-logo-footylogos.png',
  'Villarreal CF': 'assets/clubs/villarreal-cf-logo-footylogos.png',
  'AEK Athens FC': 'assets/clubs/aek-athens-logo-footylogos.png',
  'LASK': 'assets/clubs/lask-logo-footylogos.png',
  'Club Brugge KV': 'assets/clubs/club-brugge-logo-footylogos.png',
  'Aston Villa': 'assets/clubs/aston-villa-logo-footylogos.png',
  'Borussia Dortmund': 'assets/clubs/borussia-dortmund-logo-footylogos.png',
  'FC Porto': 'assets/clubs/fc-porto-logo-footylogos.png',
  'Manchester City': 'assets/clubs/manchester-city-logo-footylogos.png',
  'LOSC Lille': 'assets/clubs/losc-lille-logo-footylogos.png',
  'Real Betis Balompié': 'assets/clubs/real-betis-balompie-logo-footylogos.png',
  'FC Internazionale Milano': 'assets/clubs/inter-milan-logo-footylogos.png',
  'FC Barcelona': 'assets/clubs/fc-barcelona-logo-footylogos.png',
  'Feyenoord': 'assets/clubs/feyenoord-logo-footylogos.png',
  'Liverpool FC': 'assets/clubs/liverpool-fc-logo-footylogos.png',
  'Atlético de Madrid': 'assets/clubs/atletico-madrid-logo-footylogos.png',
  'Paris Saint-Germain': 'assets/clubs/paris-saint-germain-psg-logo-footylogos.png',
  'SSC Napoli': 'assets/clubs/napoli-logo-footylogos.png',
  'Arsenal FC': 'assets/clubs/arsenal-logo-footylogos.png',
  'Fenerbahçe SK': 'assets/clubs/fenerbahce-logo-footylogos.png',
  'PSV Eindhoven': 'assets/clubs/psv-eindhoven-logo-footylogos.png',
  'Como 1907': 'assets/clubs/como-1907-logo-footylogos.png',
  'RB Leipzig': 'assets/clubs/rb-leipzig-logo-footylogos.png',
  'FC Bayern München': 'assets/clubs/bayern-munich-logo-footylogos.png',
  'FK Bodø/Glimt': 'assets/clubs/fk-bodo-glimt-logo-footylogos.png',
  'Manchester United': 'assets/clubs/manchester-united-logo-footylogos.png',
  'RC Lens': 'assets/clubs/rc-lens-logo-footylogos.png',
  'Galatasaray A.Ş.': 'assets/clubs/galatasaray-logo-footylogos.png',
  'Real Madrid': 'assets/clubs/real-madrid-logo-footylogos.png',
  'Sabah FK': 'assets/clubs/sabah-fk-logo-footylogos.png',
  'Shakhtar Donetsk': 'assets/clubs/shakhtar-donetsk-logo-footylogos.png',
  'Slovan Bratislava': 'assets/clubs/sk-slovan-bratislava-logo-footylogos.png',
  'Slavia Prague': 'assets/clubs/slavia-praha-logo-footylogos.png',
  'Sporting CP': 'assets/clubs/sporting-cp-logo-footylogos.png',
};

class GabfootApp extends StatelessWidget {
  const GabfootApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GABFOOT AI',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: pageBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: electricBlue,
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: pageBg,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;
  final tabs = const ['Accueil', 'Live', 'Compétitions', 'GABFOOT AI', 'Favoris'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.sports_soccer, color: electricBlue, size: 27),
            SizedBox(width: 9),
            Text('GAB', style: TextStyle(fontWeight: FontWeight.w900)),
            Text('FOOT', style: TextStyle(
              color: electricBlue, fontWeight: FontWeight.w900)),
            SizedBox(width: 7),
            Text('AI', style: TextStyle(
              fontSize: 11, color: Colors.white70,
              fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.search, color: Colors.white),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none, color: Colors.white),
          ),
        ],
      ),
      body: IndexedStack(
        index: selectedTab,
        children: const [
          DashboardPage(),
          SimplePage(title: 'Matchs en direct', icon: Icons.sensors),
          CalendarPage(),
          PredictionsPage(),
          SimplePage(title: 'Mes favoris', icon: Icons.star_outline),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0D1522),
        indicatorColor: electricBlue.withOpacity(.22),
        selectedIndex: selectedTab,
        onDestinationSelected: (i) => setState(() => selectedTab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.sensors), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Ligues'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'IA'),
          NavigationDestination(icon: Icon(Icons.star_outline), label: 'Favoris'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [Color(0xFF123C70), Color(0xFF101A2B)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: electricBlue.withOpacity(.45)),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('FOOTBALL INTELLIGENCE',
                style: TextStyle(color: Colors.white70, letterSpacing: 1.4,
                  fontSize: 11, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Les matchs. Les chiffres.\\nUne nouvelle lecture du jeu.',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              SizedBox(height: 12),
              Row(children: [
                Icon(Icons.auto_awesome, color: electricBlue, size: 17),
                SizedBox(width: 6),
                Text('Analyses et probabilités par GABFOOT AI',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const SectionTitle(title: 'Matchs du jour', trailing: 'Tous les matchs'),
        const SizedBox(height: 10),
        const MatchCard(
          league: 'UEFA Champions League',
          time: '20:00',
          home: 'Real Madrid',
          away: 'Manchester City',
          homeCode: 'RMA',
          awayCode: 'MCI',
          status: 'À VENIR',
        ),
        const MatchCard(
          league: 'Premier League',
          time: '17:30',
          home: 'Arsenal',
          away: 'Liverpool',
          homeCode: 'ARS',
          awayCode: 'LIV',
          status: 'À VENIR',
        ),
        const SizedBox(height: 10),
        const SectionTitle(title: 'Clubs intégrés', trailing: '36 logos'),
        const SizedBox(height: 10),
        const ClubLogoStrip(),
        const SizedBox(height: 20),
        const SectionTitle(title: 'Aperçu GABFOOT AI', trailing: 'Voir analyses'),
        const SizedBox(height: 10),
        const ProbabilityPreview(),
        const SizedBox(height: 14),
        const Text(
          'Prototype : les matchs et probabilités affichés ici sont des exemples '
          'de démonstration. Les données réelles seront connectées après '
          'configuration du fournisseur API.',
          style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.5),
        ),
      ],
    );
  }
}

class MatchCard extends StatelessWidget {
  final String league, time, home, away, homeCode, awayCode, status;
  const MatchCard({
    super.key, required this.league, required this.time,
    required this.home, required this.away, required this.homeCode,
    required this.awayCode, required this.status,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: cardBg,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Row(children: [
            const Icon(Icons.emoji_events_outlined, color: Colors.amber, size: 15),
            const SizedBox(width: 6),
            Expanded(child: Text(league,
              style: const TextStyle(color: Colors.white70, fontSize: 11))),
            Text(status, style: const TextStyle(
              color: electricBlue, fontSize: 10, fontWeight: FontWeight.bold)),
          ]),
          const Divider(color: Colors.white12, height: 22),
          Row(children: [
            Expanded(child: TeamLabel(name: home, code: homeCode)),
            Column(children: [
              Text(time, style: const TextStyle(
                fontSize: 17, fontWeight: FontWeight.w800)),
              const Text('VS', style: TextStyle(
                color: Colors.white54, fontSize: 10)),
            ]),
            Expanded(child: TeamLabel(name: away, code: awayCode, right: true)),
          ]),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const MatchAnalysisPage())),
              icon: const Icon(Icons.auto_awesome, size: 16),
              label: const Text('Voir analyse IA'),
              style: OutlinedButton.styleFrom(
                foregroundColor: electricBlue,
                side: BorderSide(color: electricBlue.withOpacity(.6)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class TeamLabel extends StatelessWidget {
  final String name, code;
  final bool right;
  const TeamLabel({super.key, required this.name, required this.code,
    this.right = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        _ClubBadge(teamName: name, code: code, size: 38),
        const SizedBox(height: 6),
        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
      ],
    );
  }
}

class _ClubBadge extends StatelessWidget {
  final String teamName;
  final String code;
  final double size;
  const _ClubBadge({required this.teamName, required this.code, this.size = 42});

  @override
  Widget build(BuildContext context) {
    final asset = clubLogos[teamName];
    if (asset == null) {
      return CircleAvatar(
        radius: size / 2,
        backgroundColor: electricBlue.withOpacity(.16),
        child: Text(code.isEmpty ? '?' : code.substring(0, 1),
          style: const TextStyle(color: electricBlue, fontWeight: FontWeight.bold)),
      );
    }
    return Container(
      width: size, height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: electricBlue.withOpacity(.35)),
      ),
      child: Image.asset(asset, fit: BoxFit.contain),
    );
  }
}

class ClubLogoStrip extends StatelessWidget {
  const ClubLogoStrip({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 94,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: clubLogos.entries.map((entry) => Container(
          width: 76,
          margin: const EdgeInsets.only(right: 9),
          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 5),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(children: [
            Expanded(child: Image.asset(entry.value, fit: BoxFit.contain)),
            const SizedBox(height: 5),
            Text(entry.key, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 9, color: Colors.white70)),
          ]),
        )).toList(),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title, trailing;
  const SectionTitle({super.key, required this.title, required this.trailing});
  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      Text(trailing, style: const TextStyle(color: electricBlue, fontSize: 11)),
    ],
  );
}

class ProbabilityPreview extends StatelessWidget {
  const ProbabilityPreview({super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: cardBg, borderRadius: BorderRadius.circular(15),
      border: Border.all(color: electricBlue.withOpacity(.22)),
    ),
    child: const Column(children: [
      Row(children: [
        Icon(Icons.auto_awesome, color: electricBlue),
        SizedBox(width: 8),
        Text('Exemple d’analyse — Real Madrid vs Man City',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
      ]),
      SizedBox(height: 16),
      ProbabilityBar(label: 'Victoire équipe 1', value: 42),
      ProbabilityBar(label: 'Match nul', value: 26),
      ProbabilityBar(label: 'Victoire équipe 2', value: 32),
    ]),
  );
}

class ProbabilityBar extends StatelessWidget {
  final String label;
  final int value;
  const ProbabilityBar({super.key, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
        Text('$value%', style: const TextStyle(
          color: electricBlue, fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 6),
      ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: LinearProgressIndicator(
          value: value / 100, minHeight: 7,
          backgroundColor: Colors.white10, color: electricBlue,
        ),
      ),
    ]),
  );
}


// Calendrier UEFA Champions League 2026/27 extrait du calendrier fourni.
const championsLeagueCalendar = <Map<String, dynamic>>[
  {'round': 1, 'fixtures': [
    {'date': 'Tuesday 8 September 2026', 'time': '18:45', 'home': 'AEK Athens FC', 'away': 'LASK'},
    {'date': 'Tuesday 8 September 2026', 'time': '18:45', 'home': 'Club Brugge KV', 'away': 'Aston Villa'},
    {'date': 'Tuesday 8 September 2026', 'time': '21:00', 'home': 'Borussia Dortmund', 'away': 'Villarreal CF'},
    {'date': 'Tuesday 8 September 2026', 'time': '21:00', 'home': 'FC Porto', 'away': 'Manchester City'},
    {'date': 'Tuesday 8 September 2026', 'time': '21:00', 'home': 'LOSC Lille', 'away': 'Real Betis Balompié'},
    {'date': 'Tuesday 8 September 2026', 'time': '21:00', 'home': 'Real Madrid C.F.', 'away': 'FC Internazionale Milano'},
    {'date': 'Wednesday 9 September 2026', 'time': '18:45', 'home': 'FC Barcelona', 'away': 'Feyenoord'},
    {'date': 'Wednesday 9 September 2026', 'time': '18:45', 'home': 'VfB Stuttgart', 'away': 'Viking FK'},
    {'date': 'Wednesday 9 September 2026', 'time': '21:00', 'home': 'Liverpool FC', 'away': 'Atlético de Madrid'},
    {'date': 'Wednesday 9 September 2026', 'time': '21:00', 'home': 'Paris Saint-Germain', 'away': 'ŠK Slovan Bratislava'},
    {'date': 'Wednesday 9 September 2026', 'time': '21:00', 'home': 'Sporting Clube de Portugal', 'away': 'Galatasaray A.Ş.'},
    {'date': 'Wednesday 9 September 2026', 'time': '21:00', 'home': 'SSC Napoli', 'away': 'Arsenal FC'},
    {'date': 'Thursday 10 September 2026', 'time': '18:45', 'home': 'Fenerbahçe SK', 'away': 'AS Roma'},
    {'date': 'Thursday 10 September 2026', 'time': '18:45', 'home': 'PSV Eindhoven', 'away': 'FC Shakhtar Donetsk'},
    {'date': 'Thursday 10 September 2026', 'time': '21:00', 'home': 'Como 1907', 'away': 'RB Leipzig'},
    {'date': 'Thursday 10 September 2026', 'time': '21:00', 'home': 'FC Bayern München', 'away': 'FK Bodø/Glimt'},
    {'date': 'Thursday 10 September 2026', 'time': '21:00', 'home': 'Manchester United', 'away': 'Sabah FC'},
    {'date': 'Thursday 10 September 2026', 'time': '21:00', 'home': 'SK Slavia Praha', 'away': 'RC Lens'},
  ]},
  {'round': 2, 'fixtures': [
    {'date': 'Tuesday 13 October 2026', 'time': '18:45', 'home': 'RC Lens', 'away': 'Sporting Clube de Portugal'},
    {'date': 'Tuesday 13 October 2026', 'time': '18:45', 'home': 'Sabah FC', 'away': 'SK Slavia Praha'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'Arsenal FC', 'away': 'LOSC Lille'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'Atlético de Madrid', 'away': 'Manchester United'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'FC Internazionale Milano', 'away': 'Club Brugge KV'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'Galatasaray A.Ş.', 'away': 'FC Barcelona'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'RB Leipzig', 'away': 'PSV Eindhoven'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'Viking FK', 'away': 'FC Bayern München'},
    {'date': 'Tuesday 13 October 2026', 'time': '21:00', 'home': 'Villarreal CF', 'away': 'SSC Napoli'},
    {'date': 'Wednesday 14 October 2026', 'time': '18:45', 'home': 'Feyenoord', 'away': 'Como 1907'},
    {'date': 'Wednesday 14 October 2026', 'time': '18:45', 'home': 'LASK', 'away': 'Liverpool FC'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'AS Roma', 'away': 'Real Madrid C.F.'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'Aston Villa', 'away': 'Fenerbahçe SK'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'FC Shakhtar Donetsk', 'away': 'AEK Athens FC'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'FK Bodø/Glimt', 'away': 'Borussia Dortmund'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'Manchester City', 'away': 'Paris Saint-Germain'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'Real Betis Balompié', 'away': 'FC Porto'},
    {'date': 'Wednesday 14 October 2026', 'time': '21:00', 'home': 'ŠK Slovan Bratislava', 'away': 'VfB Stuttgart'},
  ]},
  {'round': 3, 'fixtures': [
    {'date': 'Tuesday 20 October 2026', 'time': '18:45', 'home': 'Fenerbahçe SK', 'away': 'SK Slavia Praha'},
    {'date': 'Tuesday 20 October 2026', 'time': '18:45', 'home': 'Sabah FC', 'away': 'Borussia Dortmund'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'AS Roma', 'away': 'ŠK Slovan Bratislava'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'FC Porto', 'away': 'PSV Eindhoven'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'Liverpool FC', 'away': 'Villarreal CF'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'Manchester City', 'away': 'AEK Athens FC'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'Paris Saint-Germain', 'away': 'FC Barcelona'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'SSC Napoli', 'away': 'FK Bodø/Glimt'},
    {'date': 'Tuesday 20 October 2026', 'time': '21:00', 'home': 'VfB Stuttgart', 'away': 'Atlético de Madrid'},
    {'date': 'Wednesday 21 October 2026', 'time': '18:45', 'home': 'Como 1907', 'away': 'Manchester United'},
    {'date': 'Wednesday 21 October 2026', 'time': '18:45', 'home': 'LOSC Lille', 'away': 'Galatasaray A.Ş.'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'Aston Villa', 'away': 'Viking FK'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'Club Brugge KV', 'away': 'RC Lens'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'FC Bayern München', 'away': 'Arsenal FC'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'FC Internazionale Milano', 'away': 'FC Shakhtar Donetsk'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'Real Madrid C.F.', 'away': 'RB Leipzig'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'Real Betis Balompié', 'away': 'Feyenoord'},
    {'date': 'Wednesday 21 October 2026', 'time': '21:00', 'home': 'Sporting Clube de Portugal', 'away': 'LASK'},
  ]},
  {'round': 4, 'fixtures': [
    {'date': 'Tuesday 3 November 2026', 'time': '18:45', 'home': 'FC Shakhtar Donetsk', 'away': 'Sporting Clube de Portugal'},
    {'date': 'Tuesday 3 November 2026', 'time': '18:45', 'home': 'Galatasaray A.Ş.', 'away': 'VfB Stuttgart'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'Atlético de Madrid', 'away': 'FC Bayern München'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'FC Barcelona', 'away': 'Aston Villa'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'Feyenoord', 'away': 'FC Internazionale Milano'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'FK Bodø/Glimt', 'away': 'LOSC Lille'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'LASK', 'away': 'ŠK Slovan Bratislava'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'Manchester United', 'away': 'AS Roma'},
    {'date': 'Tuesday 3 November 2026', 'time': '21:00', 'home': 'Villarreal CF', 'away': 'Paris Saint-Germain'},
    {'date': 'Wednesday 4 November 2026', 'time': '18:45', 'home': 'AEK Athens FC', 'away': 'Real Madrid C.F.'},
    {'date': 'Wednesday 4 November 2026', 'time': '18:45', 'home': 'Fenerbahçe SK', 'away': 'Liverpool FC'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'Borussia Dortmund', 'away': 'Real Betis Balompié'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'FC Porto', 'away': 'SSC Napoli'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'PSV Eindhoven', 'away': 'Club Brugge KV'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'RB Leipzig', 'away': 'Manchester City'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'RC Lens', 'away': 'Como 1907'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'SK Slavia Praha', 'away': 'Arsenal FC'},
    {'date': 'Wednesday 4 November 2026', 'time': '21:00', 'home': 'Viking FK', 'away': 'Sabah FC'},
  ]},
  {'round': 5, 'fixtures': [
    {'date': 'Tuesday 24 November 2026', 'time': '18:45', 'home': 'FK Bodø/Glimt', 'away': 'LASK'},
    {'date': 'Tuesday 24 November 2026', 'time': '18:45', 'home': 'Galatasaray A.Ş.', 'away': 'Aston Villa'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'Arsenal FC', 'away': 'Borussia Dortmund'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'Como 1907', 'away': 'AEK Athens FC'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'Feyenoord', 'away': 'FC Porto'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'Manchester City', 'away': 'SSC Napoli'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'RB Leipzig', 'away': 'RC Lens'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'Real Madrid C.F.', 'away': 'PSV Eindhoven'},
    {'date': 'Tuesday 24 November 2026', 'time': '21:00', 'home': 'ŠK Slovan Bratislava', 'away': 'Real Betis Balompié'},
    {'date': 'Wednesday 25 November 2026', 'time': '18:45', 'home': 'Sabah FC', 'away': 'FC Barcelona'},
    {'date': 'Wednesday 25 November 2026', 'time': '18:45', 'home': 'SK Slavia Praha', 'away': 'Villarreal CF'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'Atlético de Madrid', 'away': 'Viking FK'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'Club Brugge KV', 'away': 'Liverpool FC'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'FC Internazionale Milano', 'away': 'VfB Stuttgart'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'FC Shakhtar Donetsk', 'away': 'Fenerbahçe SK'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'LOSC Lille', 'away': 'FC Bayern München'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'Paris Saint-Germain', 'away': 'AS Roma'},
    {'date': 'Wednesday 25 November 2026', 'time': '21:00', 'home': 'Sporting Clube de Portugal', 'away': 'Manchester United'},
  ]},
  {'round': 6, 'fixtures': [
    {'date': 'Tuesday 8 December 2026', 'time': '18:45', 'home': 'Viking FK', 'away': 'Feyenoord'},
    {'date': 'Tuesday 8 December 2026', 'time': '18:45', 'home': 'Villarreal CF', 'away': 'Sabah FC'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'AEK Athens FC', 'away': 'Galatasaray A.Ş.'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'AS Roma', 'away': 'Sporting Clube de Portugal'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'Aston Villa', 'away': 'Paris Saint-Germain'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'FC Barcelona', 'away': 'Manchester City'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'FC Bayern München', 'away': 'SK Slavia Praha'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'Manchester United', 'away': 'RB Leipzig'},
    {'date': 'Tuesday 8 December 2026', 'time': '21:00', 'home': 'SSC Napoli', 'away': 'Club Brugge KV'},
    {'date': 'Wednesday 9 December 2026', 'time': '18:45', 'home': 'Real Betis Balompié', 'away': 'Como 1907'},
    {'date': 'Wednesday 9 December 2026', 'time': '18:45', 'home': 'ŠK Slovan Bratislava', 'away': 'FC Shakhtar Donetsk'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'Arsenal FC', 'away': 'Real Madrid C.F.'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'Borussia Dortmund', 'away': 'FC Internazionale Milano'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'LASK', 'away': 'Fenerbahçe SK'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'Liverpool FC', 'away': 'FC Porto'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'PSV Eindhoven', 'away': 'Atlético de Madrid'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'RC Lens', 'away': 'FK Bodø/Glimt'},
    {'date': 'Wednesday 9 December 2026', 'time': '21:00', 'home': 'VfB Stuttgart', 'away': 'LOSC Lille'},
  ]},
  {'round': 7, 'fixtures': [
    {'date': 'Tuesday 19 January 2027', 'time': '18:45', 'home': 'FK Bodø/Glimt', 'away': 'Atlético de Madrid'},
    {'date': 'Tuesday 19 January 2027', 'time': '18:45', 'home': 'Galatasaray A.Ş.', 'away': 'Feyenoord'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'AEK Athens FC', 'away': 'AS Roma'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'Aston Villa', 'away': 'Borussia Dortmund'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'FC Internazionale Milano', 'away': 'Liverpool FC'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'FC Porto', 'away': 'SK Slavia Praha'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'LOSC Lille', 'away': 'ŠK Slovan Bratislava'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'Real Madrid C.F.', 'away': 'LASK'},
    {'date': 'Tuesday 19 January 2027', 'time': '21:00', 'home': 'VfB Stuttgart', 'away': 'Club Brugge KV'},
    {'date': 'Wednesday 20 January 2027', 'time': '18:45', 'home': 'Fenerbahçe SK', 'away': 'Villarreal CF'},
    {'date': 'Wednesday 20 January 2027', 'time': '18:45', 'home': 'Sabah FC', 'away': 'SSC Napoli'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'Como 1907', 'away': 'Paris Saint-Germain'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'Manchester United', 'away': 'FC Bayern München'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'RB Leipzig', 'away': 'FC Shakhtar Donetsk'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'RC Lens', 'away': 'Manchester City'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'Real Betis Balompié', 'away': 'Arsenal FC'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'Sporting Clube de Portugal', 'away': 'FC Barcelona'},
    {'date': 'Wednesday 20 January 2027', 'time': '21:00', 'home': 'Viking FK', 'away': 'PSV Eindhoven'},
  ]},
  {'round': 8, 'fixtures': [
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Arsenal FC', 'away': 'Sabah FC'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'AS Roma', 'away': 'LOSC Lille'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Atlético de Madrid', 'away': 'Fenerbahçe SK'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Borussia Dortmund', 'away': 'AEK Athens FC'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Club Brugge KV', 'away': 'FK Bodø/Glimt'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'FC Bayern München', 'away': 'Real Betis Balompié'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'FC Barcelona', 'away': 'Como 1907'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'FC Shakhtar Donetsk', 'away': 'Real Madrid C.F.'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Feyenoord', 'away': 'RB Leipzig'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'LASK', 'away': 'FC Porto'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Liverpool FC', 'away': 'RC Lens'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Manchester City', 'away': 'Sporting Clube de Portugal'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Paris Saint-Germain', 'away': 'Galatasaray A.Ş.'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'PSV Eindhoven', 'away': 'VfB Stuttgart'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'SK Slavia Praha', 'away': 'Aston Villa'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'SSC Napoli', 'away': 'Viking FK'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'Villarreal CF', 'away': 'Manchester United'},
    {'date': 'Wednesday 27 January 2027', 'time': '21:00', 'home': 'ŠK Slovan Bratislava', 'away': 'FC Internazionale Milano'},
  ]},
];

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key});
  @override State<CalendarPage> createState() => _CalendarPageState();
}
class _CalendarPageState extends State<CalendarPage> {
  int selectedRound = 1;
  @override Widget build(BuildContext context) {
    final round = championsLeagueCalendar.firstWhere((r) => r['round'] == selectedRound);
    final fixtures = round['fixtures'] as List<Map<String, String>>;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Row(children: [
        Container(width: 58, height: 58, padding: const EdgeInsets.all(5), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: Image.asset('assets/competitions/uefa-champions-league.png', fit: BoxFit.contain)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CALENDRIER DES MATCHS', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          SizedBox(height: 4), Text('UEFA Champions League • 2026/27', style: TextStyle(color: Colors.white60, fontSize: 12)),
        ])),
      ])),
      SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        for (int i = 1; i <= 8; i++) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text('Journée $i'), selected: selectedRound == i, selectedColor: electricBlue, backgroundColor: cardBg, onSelected: (_) => setState(() => selectedRound = i))),
      ])),
      Expanded(child: ListView.builder(padding: const EdgeInsets.fromLTRB(14, 8, 14, 18), itemCount: fixtures.length, itemBuilder: (context, index) {
        final f = fixtures[index];
        return Card(color: cardBg, margin: const EdgeInsets.only(bottom: 9), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
          Row(children: [const Icon(Icons.emoji_events_outlined, color: Colors.amber, size: 14), const SizedBox(width: 6), Expanded(child: Text(f['date']!, style: const TextStyle(color: Colors.white60, fontSize: 11))), Text(f['time']!, style: const TextStyle(color: electricBlue, fontWeight: FontWeight.bold, fontSize: 12))]),
          const SizedBox(height: 10), Row(children: [Expanded(child: _CalendarTeam(name: f['home']!, right: false)), const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('VS', style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold))), Expanded(child: _CalendarTeam(name: f['away']!, right: true))]),
        ])));
      })),
    ]);
  }
}
class _CalendarTeam extends StatelessWidget {
  final String name; final bool right; const _CalendarTeam({required this.name, required this.right});
  @override Widget build(BuildContext context) {
    final code = name.split(' ').where((p) => p.isNotEmpty).take(3).map((p) => p[0]).join().toUpperCase();
    return Row(mainAxisAlignment: right ? MainAxisAlignment.end : MainAxisAlignment.start, children: [
      if (!right) ...[_ClubBadge(teamName: name, code: code, size: 34), const SizedBox(width: 7)],
      Flexible(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: right ? TextAlign.right : TextAlign.left, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
      if (right) ...[const SizedBox(width: 7), _ClubBadge(teamName: name, code: code, size: 34)],
    ]);
  }
}

class PredictionsPage extends StatelessWidget {
  const PredictionsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Text('GABFOOT AI', style: TextStyle(
        fontSize: 24, fontWeight: FontWeight.w900, color: electricBlue)),
      SizedBox(height: 8),
      Text('Analyses prédictives des rencontres',
        style: TextStyle(color: Colors.white70)),
      SizedBox(height: 18),
      MatchCard(league: 'Exemple de compétition', time: '20:00',
        home: 'Équipe 1', away: 'Équipe 2', homeCode: 'E1',
        awayCode: 'E2', status: 'DÉMO'),
      Text('Les pourcentages définitifs seront calculés à partir des statistiques '
        'réelles et des modèles validés. Aucun pronostic ne garantit un résultat.',
        style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5)),
    ],
  );
}

class MatchAnalysisPage extends StatelessWidget {
  const MatchAnalysisPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Analyse du match')),
    body: ListView(padding: const EdgeInsets.all(16), children: const [
      Text('Real Madrid  vs  Manchester City',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('Probabilités de démonstration',
        textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
      SizedBox(height: 20),
      ProbabilityBar(label: '1 — Victoire équipe 1', value: 42),
      ProbabilityBar(label: 'X — Match nul', value: 26),
      ProbabilityBar(label: '2 — Victoire équipe 2', value: 32),
      Divider(color: Colors.white12, height: 28),
      ProbabilityBar(label: 'Double chance 1X', value: 68),
      ProbabilityBar(label: 'Double chance 12', value: 74),
      ProbabilityBar(label: 'Double chance X2', value: 58),
      Divider(color: Colors.white12, height: 28),
      ProbabilityBar(label: 'Les deux équipes marquent — OUI', value: 61),
      ProbabilityBar(label: 'Les deux équipes marquent — NON', value: 39),
      SizedBox(height: 12),
      Text('Les statistiques détaillées (buts, tirs, tirs cadrés, fautes et corners) '
        'seront ajoutées avec la connexion à une API qui fournit ces données.',
        style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5)),
    ]),
  );
}

class SimplePage extends StatelessWidget {
  final String title;
  final IconData icon;
  const SimplePage({super.key, required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 48, color: electricBlue),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Cette section sera connectée aux données réelles.',
        style: TextStyle(color: Colors.white54)),
    ]),
  );
}
